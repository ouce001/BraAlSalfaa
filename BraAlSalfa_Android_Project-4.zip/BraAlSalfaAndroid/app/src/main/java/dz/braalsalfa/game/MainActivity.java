package dz.braalsalfa.game;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<Player> players = new ArrayList<>();
    final String[] characters = {
        "بلال محمدي","يوسف طاهيري","خالد براهيمي","لهزيل باديس","لهويل وائل",
        "أستاذ أدب","بورزقة نتاع فرونسي","ريكي نتاع رياضيات",
        "أستاذة علوم لي درنا عليها حملة","نويجم نتاع علوم","ياسر نتاع فيزياء",
        "أستاذ نور دين","أستاذ مجواير نتاع إسلامية","ڨنان نتاع إنجليزية",
        "قدور فكرون","رشيد قاصف","عاصم طويل","كمال لي يسقسي على باك","حنافي المضحك"
    };
    Random random = new Random();
    String secret; int outsider, current, voter; int[] votes;

    static class Player { String name; int score=0; Player(String n){name=n;} }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setupBase(); setup();
    }

    void setupBase() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,24,28,24); root.setBackgroundColor(Color.rgb(17,24,39));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    TextView title(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setPadding(5,12,5,12); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); return b; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.LTGRAY); return e; }
    void clear(){content.removeAllViews();}
    void setup(){
        clear(); content.addView(title("🎭 برا السالفة",34)); content.addView(title("لعبة الشخص الذي لا يعرف السالفة",16));
        EditText count=input("عدد اللاعبين (3 - 20)"); count.setInputType(2); count.setText("4"); content.addView(count);
        Button ok=btn("تأكيد العدد"); content.addView(ok);
        LinearLayout names=new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL); content.addView(names);
        ok.setOnClickListener(v->{
            names.removeAllViews(); int n=Math.max(3,Math.min(20,Integer.parseInt(count.getText().toString())));
            for(int i=0;i<n;i++) names.addView(input("اسم اللاعب "+(i+1)));
        });
        Button start=btn("🚀 ابدأ اللعبة"); content.addView(start);
        start.setOnClickListener(v->{
            if(names.getChildCount()<3){Toast.makeText(this,"اضغط تأكيد العدد أولاً",Toast.LENGTH_SHORT).show();return;}
            players.clear();
            for(int i=0;i<names.getChildCount();i++){String n=((EditText)names.getChildAt(i)).getText().toString().trim(); if(n.isEmpty()){Toast.makeText(this,"أدخل جميع الأسماء",Toast.LENGTH_SHORT).show();return;} players.add(new Player(n));}
            newRound(); showPass();
        });
    }
    void newRound(){ secret=characters[random.nextInt(characters.length)]; outsider=random.nextInt(players.size()); current=0; voter=0; votes=new int[players.size()]; Arrays.fill(votes,-1); }
    void showPass(){
        clear(); content.addView(title("📱 مرر الهاتف",28)); content.addView(title("أعط الهاتف للاعب: "+players.get(current).name,20));
        Button b=btn("أنا مستعد");content.addView(b);b.setOnClickListener(v->showSecret());
    }
    void showSecret(){
        clear(); boolean out=current==outsider; content.addView(title(players.get(current).name,28));
        TextView s=title(out?"🚫 أنت برا السالفة":"🔐 السالفة: "+secret,27); content.addView(s);
        Button b=btn("التالي");content.addView(b);b.setOnClickListener(v->{current++; if(current<players.size())showPass();else showQuestions();});
    }
    void showQuestions(){
        clear();content.addView(title("🗣️ انتهى توزيع الأدوار",28));content.addView(title("ناقشوا الآن وحاولوا معرفة برا السالفة.",18));
        Button b=btn("🗳️ ابدأ التصويت");content.addView(b);b.setOnClickListener(v->{voter=0;showVote();});
    }
    void showVote(){
        clear();content.addView(title("🗳️ تصويت فردي",27));content.addView(title("دور: "+players.get(voter).name,20));
        content.addView(title("لا تُظهر اختيارك لبقية اللاعبين.",14));
        for(int i=0;i<players.size();i++){ final int x=i; if(i==voter)continue; Button b=btn(players.get(i).name);content.addView(b);b.setOnClickListener(v->{votes[voter]=x;voter++;if(voter<players.size())showVote();else finishVoting();});}
    }
    void finishVoting(){
        int[] c=new int[players.size()];for(int x:votes)if(x>=0)c[x]++;
        int max=0;for(int x:c)max=Math.max(max,x);ArrayList<Integer> top=new ArrayList<>();for(int i=0;i<c.length;i++)if(c[i]==max)top.add(i);
        int voted=top.get(random.nextInt(top.size()));clear();content.addView(title("🎯 النتيجة",28));
        if(voted==outsider){for(int i=0;i<players.size();i++)if(i!=outsider)players.get(i).score+=100;content.addView(title("🎉 تم كشف برا السالفة!",20));}
        else {players.get(outsider).score+=100;content.addView(title("😈 التصويت خاطئ!",20));}
        content.addView(title("برا السالفة هو: "+players.get(outsider).name,21));
        Button b=btn("🤔 تخمين الشخصية");content.addView(b);b.setOnClickListener(v->guess());
    }
    void guess(){
        clear();content.addView(title("🤔 تخمين الشخصية",27));content.addView(title(players.get(outsider).name+"، اختر الشخصية:",18));
        Spinner sp=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,characters);sp.setAdapter(a);content.addView(sp);
        Button b=btn("تأكيد التخمين");content.addView(b);b.setOnClickListener(v->{if(sp.getSelectedItem().toString().equals(secret))players.get(outsider).score+=100;else players.get(outsider).score-=100;showScores();});
    }
    void showScores(){
        clear();content.addView(title("🏆 التصنيف",29));ArrayList<Player> sorted=new ArrayList<>(players);Collections.sort(sorted,(a,b)->b.score-a.score);
        for(int i=0;i<sorted.size();i++){Player p=sorted.get(i);TextView t=title("#"+(i+1)+"  "+p.name+" — "+p.score+" نقطة"+(i==sorted.size()-1?" 👑 القاعقاع":""),19);content.addView(t);}
        Button b=btn("🔄 جولة جديدة");content.addView(b);b.setOnClickListener(v->{newRound();showPass();});
    }
}